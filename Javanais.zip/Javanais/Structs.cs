﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Javanais
{
    public class Structs
    {
        public bool CheckVowels(char c)
        {
            char[] Vowels = { 'a', 'e', 'i', 'o', 'u', 'y' };

            foreach (char vowel in Vowels)
            {
                if (c == vowel)
                    return true;
                return false;
            }
            return false;
        }

        public bool CheckConsonent(char c)
        {
            char[] Consonants = { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'z' };
            foreach (char consonant in Consonants)
            {
                if (c == consonant)
                    return true;
                return false;
            }
            return false;
        }
    }
}
