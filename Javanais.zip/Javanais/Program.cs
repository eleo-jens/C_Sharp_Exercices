﻿using System;

namespace Javanais
{
    //Réalisez un algorithme qui va permettre a l'utilisateur d'encodé une phrase, cette prhase sera analyser pour etre
    //transformée en javanais.après traitemement afficher la phrase traduite ensuite, faire la meme chose en sens inverse.
    //Encodez une phrase en javanais pour ensuite la traduire en francais.

    //Les règles du javanais :

    //   - On ajoute 'av' après chaque consonne ou groupe de consonnes(comme par exemple ch, cl, ph, tr,…) d’un mot.
    //   - Si le mot commence par une voyelle, on ajoute av devant cette voyelle.
    //   - On ne rajoute jamais av après la consonne finale d’un mot.

    //Exemple : Abraracourcix => Avabravaravacavourcavix

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("JAVANAIS CODER\nIntroduisez une phrase à traduire: ");
            string input = Console.ReadLine();
            string traduction = input;
            
            for (int i = 0; i < traduction.Length - 1; i++)
            {
                if (CheckVowels(traduction[0])
                {
                    string temp = traduction.Insert(0, "av");
                    traduction = temp;
                }
                
            }

        }
    }
}
